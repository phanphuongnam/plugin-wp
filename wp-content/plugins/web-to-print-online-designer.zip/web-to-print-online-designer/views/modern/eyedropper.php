<div class="nbd-eyedropper-wrap">
    <div class="nbd-eyedropper-info-wrap">
        <div class="nbd-eyedropper-color"></div>
        <div class="nbd-eyedropper-color-code"></div>
    </div>
</div>