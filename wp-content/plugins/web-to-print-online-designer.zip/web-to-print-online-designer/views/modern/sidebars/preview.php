<div class="nbd-sidebar-preview product-more-info">
    <div class="preview-head">
        <span><?php esc_html_e('infomation','web-to-print-online-designer'); ?></span>
        <i class="icon-nbd icon-nbd-fomat-highlight-off close-preview"></i>
    </div>
    <div class="main-preview tab-scroll">
        <div class="preview-body">
        </div>
        <div class="preview-footer">
            <div class="main-footer">
                <button class="nbd-button"><?php esc_html_e('Choose','web-to-print-online-designer'); ?></button>
            </div>
        </div>
    </div>
</div>