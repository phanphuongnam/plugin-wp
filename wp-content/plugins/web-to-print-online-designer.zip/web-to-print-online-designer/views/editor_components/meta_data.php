<?php if ( ! defined( 'ABSPATH' ) ) { exit;} ?>
<meta charset="utf-8" />
<meta http-equiv="Content-type" content="text/html; charset=utf-8">
<title><?php echo get_bloginfo( 'name' ); ?> - Online Designer</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1, minimum-scale=0.5, maximum-scale=1.0"/>
<meta content="Online Designer - HTML5 Designer - Online Print Solution" name="description" />
<meta content="Online Designer" name="keywords" />
<meta content="Netbaseteam" name="author">
<?php 
    do_action('nbd_metadata');
    wp_site_icon();