<?php if (!defined('ABSPATH')) exit; ?>
<div class="nbdl-notification nbdl-notification-<?php echo $type; ?>">
    <div>
        <?php echo $message; ?>
    </div>
</div>